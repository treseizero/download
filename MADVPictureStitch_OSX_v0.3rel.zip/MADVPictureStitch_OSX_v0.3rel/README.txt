MADV360 Picture Stitching Tool (for Mac OSX)

1. Keep 'MADVPictureStitch' executable file and 'original' folder in the same directory;
2. Put original MADV360 dual-fisheye pictures（".JPG" or ".DNG" files, either from Mijia or MADVenture360 sphere camera） in original folder;
3. Click on MADVPictureStitch;
4. Take a cup of coffee;
5. Done! Stitched pictures will lay in 'stitched' folder.


MADV360图片拼接工具（Mac OSX）
1. 保持'MADVPictureStitch'可执行程序和'original'目录在相同目录下;
2. 把原始的MADV360双鱼眼照片（包括".DNG"Raw图片和".JPG"，来自米家全景相机或MADVenture360全景相机）放在original目录;
3. 点击MADVPictureStitch;
4. 稍安勿躁;
5. 完成! 在'stitched'目录下即为拼接好的图片.


